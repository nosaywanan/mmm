package com.hikvision.manager.adapter

import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup

abstract class BaseAdapter<T : Tagable, E : RecyclerView.ViewHolder> : RecyclerView.Adapter<E>() {
    protected val dataList = ArrayList<T>()
    private val dataTagMap = HashMap<Any, T>()
    override fun onCreateViewHolder(parent: ViewGroup, position: Int) = childCreateViewHolder(parent, position)

    override fun getItemCount() = dataList.size

    override fun onBindViewHolder(viewHolder: E, position: Int) {
        bindDataWithTag(position)
    }

    override fun onBindViewHolder(holder: E, position: Int, payloads: MutableList<Any>) {
        if (payloads.isEmpty()) {
            super.onBindViewHolder(holder, position, payloads)
        } else {
            childBindPayloadsData(holder, position, payloads[0])
        }
    }

    abstract fun childBindData(viewHolder: E, position: Int)
    abstract fun childBindPayloadsData(viewHolder: E, position: Int, payloads: Any)
    abstract fun childCreateViewHolder(parent: ViewGroup, position: Int): E
    protected fun dynamicNotifyItemChanged(position: Int) {
        notifyItemChanged(position)
    }

    private fun bindDataWithTag(position: Int) {
        val data = dataList[position]
        dataTagMap[data.getTag()] = data
    }

    private fun findItemByTag(tag: Any) = dataTagMap[tag]
    open fun addData(data: T, position: Int) {
        if (position > -1 && position < dataList.size) {
            dataList.add(position, data)
            notifyItemInserted(position)
            bindDataWithTag(position)
        } else {
            dataList.add(data)
            notifyItemInserted(dataList.size - 1)
            bindDataWithTag(dataList.size - 1)
        }
    }

    open fun deleteData(data: T) {
        val tag = data.getTag()
        val index = dataList.indexOf(findItemByTag(tag))
        if (index > -1) {
            dataList.removeAt(index)
            notifyItemRemoved(index)
            notifyItemRangeChanged(index, dataList.size - index)
        }
    }

    open fun updateData(data: T, addIfNotFound: Boolean = false) {
        val tag = data.getTag()
        val index = dataList.indexOf(findItemByTag(tag))
        if (index > -1) {
            dataList[index] = data
            dynamicNotifyItemChanged(index)
        } else if (addIfNotFound) {
            addData(data, -1)
        }
    }

    open fun getData(position: Int): T? = dataList[position]
    open fun getData(tag: Any) = findItemByTag(tag)
}