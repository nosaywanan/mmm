package com.hikvision.manager.adapter

interface Tagable{
    fun setTag(tag:Any)
    fun getTag():Any
}