package com.hikvision.manager.adapter

interface Checkable :Tagable{
    fun isChecked():Boolean
    fun setCheckable(checked:Boolean)
    override fun getTag():Any
}