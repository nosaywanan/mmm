package com.hikvision.manager.adapter

import android.support.annotation.LayoutRes
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.hikvision.manager.R
import kotlinx.android.synthetic.main.item_child.view.*

abstract class BaseCheckableAdapter<T : Checkable, E : BaseCheckableAdapter.BaseCheckableViewHolder> : BaseAdapter<T, E>() {
    protected val PAY_LOADS_CHECKABLE = "payloads_checkable"
    private val checkedList = ArrayList<T>()
    private val checkedMap = HashMap<Any, Boolean>()
    override fun childCreateViewHolder(parent: ViewGroup, position: Int): E {
        val holder = BaseCheckableViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_base_checkable, parent, false), childItemLayout())
        return holder as E
    }


    override fun childBindData(viewHolder: E, position: Int) {
        bindCheckBox(viewHolder, position)
    }


    override fun childBindPayloadsData(viewHolder: E, position: Int, payloads: Any) {
        if (payloads == PAY_LOADS_CHECKABLE) {
            bindCheckBox(viewHolder, position)
        }
    }

    override fun addData(data: T, position: Int) {
        super.addData(data, position)
        setCheckedState(dataList.indexOf(data),data.isChecked())
        notifyItemChanged(dataList.indexOf(data),PAY_LOADS_CHECKABLE)
    }
    private fun bindCheckBox(viewHolder: BaseCheckableViewHolder, position: Int) {
        val isChecked = getCheckedState(position)
        viewHolder.checkBox.setImageResource(if (isChecked) R.mipmap.ic_select_on else R.mipmap.ic_select_off)
        viewHolder.checkBox.setOnClickListener {
            val checked = !getCheckedState(viewHolder.adapterPosition)
            updateCheckedState(viewHolder.adapterPosition, checked)
        }
    }

    private fun getCheckedState(position: Int) = dataList[position].isChecked()
    private fun setCheckedState(position: Int, isChecked: Boolean) {
        val data = dataList[position]
        if (isChecked) {
            if (!checkedList.contains(data))
                checkedList.add(data)
        } else {
            checkedList.remove(data)
        }
        checkedMap[data.getTag()] = isChecked
        data.setCheckable(isChecked)
    }

    abstract fun childItemLayout(): Int

    fun updateCheckedState(position: Int, checked: Boolean) {
        setCheckedState(position, checked)
        notifyItemChanged(position, PAY_LOADS_CHECKABLE)
    }

    fun selectedAll() = checkedList.size == dataList.size
    fun getCheckedList() = checkedList
    open class BaseCheckableViewHolder(itemView: View, @LayoutRes childLayout: Int) : RecyclerView.ViewHolder(itemView) {
        var checkBox: ImageView = itemView.findViewById(R.id.checkbox)

        init {
            val childContainer = itemView.findViewById<ViewGroup>(R.id.child_container)
            childContainer.addView(LayoutInflater.from(itemView.context).inflate(childLayout, childContainer, false));
        }
    }
}